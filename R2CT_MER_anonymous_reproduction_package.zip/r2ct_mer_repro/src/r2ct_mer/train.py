"""Song-disjoint source selection, optimization, and frozen destination inference."""

from __future__ import annotations

import copy
import json
import math
import random
from functools import lru_cache
from pathlib import Path

import numpy as np
import pandas as pd

from .data import reserve_calibration, source_folds
from .evaluate import evaluate_tracks, residual_half_width, coverage_width, fold_summary, bootstrap_track_metrics
from .features import load_song


def set_seed(seed: int) -> None:
    import torch
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


class SongStore:
    def __init__(self, annotations: str, features: str):
        self.frame = pd.read_csv(annotations, dtype={"song_id": str})
        self.features = features
        if self.frame.duplicated(["song_id", "time"]).any():
            raise ValueError("Annotation keys are not unique")
        self.groups = {str(k): f for k, f in self.frame.groupby("song_id")}

    def resolved_backbone(self) -> tuple[str, str]:
        signatures = set()
        for sid in self.ids():
            manifest = json.loads((Path(self.features)/sid/"manifest.json").read_text())
            signatures.add((manifest["model"], manifest["revision"]))
        if len(signatures) != 1 or next(iter(signatures))[1] is None:
            raise ValueError("Track features do not share one resolved model checkpoint")
        return next(iter(signatures))

    @lru_cache(maxsize=12)
    def get(self, song_id: str) -> dict:
        return load_song(self.groups[song_id], self.features)

    def ids(self) -> list[str]:
        return sorted(self.groups)


def new_model(protocol: dict, variant: str, device: str):
    from .model import R2CTMER
    model = R2CTMER(width=protocol["feature_width"], score_width=protocol["scoring_width"],
                    offsets=tuple(protocol["offset_seconds"]), max_delay=protocol["max_delay_seconds"],
                    variant=variant).to(device)
    return model


def variant_parameters(parameters: dict, variant: str) -> dict:
    selected = dict(parameters)
    if variant in {"no_reliability_loss", "no_gate", "fixed_probe", "tcn_probe"}:
        selected["lambda_r"] = 0.0
    if variant in {"no_anchor_loss", "fixed_probe", "tcn_probe", "no_anchor"}:
        selected["lambda_b"] = 0.0
    if variant in {"fixed_probe", "tcn_probe", "zero_delay"}:
        selected["lambda_delta"] = 0.0
    return selected


def predict(model, store: SongStore, song_ids: list[str], device: str) -> pd.DataFrame:
    import torch
    model.eval()
    output = []
    with torch.no_grad():
        for sid in song_ids:
            song = store.get(sid)
            p, _ = model.forward_song(song["windows"], torch.as_tensor(song["time"], device=device))
            base = store.groups[sid].set_index("time").loc[song["time"]].reset_index()
            base["pred_v"], base["pred_a"] = p.cpu().numpy().T
            output.append(base)
    return pd.concat(output, ignore_index=True)


def fit_model(store: SongStore, train_ids: list[str], validation_ids: list[str] | None,
              protocol: dict, params: dict, seed: int, device: str,
              variant: str = "full", epochs: int | None = None):
    import torch
    from .model import training_objective
    params = variant_parameters(params, variant)
    set_seed(seed)
    forward_variant = "full" if variant in {"no_reliability_loss", "no_anchor_loss"} else variant
    model = new_model(protocol, forward_variant, device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=params["learning_rate"],
                                  weight_decay=protocol["weight_decay"])
    iterations = epochs or protocol["maximum_epochs"]
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=iterations,
                                                            eta_min=protocol["final_learning_rate"])
    best, best_epoch, stagnant, best_metrics, history = math.inf, 0, 0, None, []
    for epoch in range(1, iterations+1):
        model.train()
        rng = np.random.default_rng(seed + epoch)
        shuffled = rng.permutation(train_ids)
        losses = []
        for offset in range(0, len(shuffled), protocol["batch_songs"]):
            batch = [store.get(str(x)) for x in shuffled[offset:offset+protocol["batch_songs"]]]
            optimizer.zero_grad(set_to_none=True)
            loss, _ = training_objective(model, batch, params)
            if not torch.isfinite(loss):
                raise FloatingPointError(f"Nonfinite training objective, epoch {epoch}")
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), protocol["gradient_clip"])
            optimizer.step()
            losses.append(float(loss.detach()))
        scheduler.step()
        row = {"epoch": epoch, "train_loss": float(np.mean(losses))}
        if validation_ids:
            metrics = evaluate_tracks(predict(model, store, validation_ids, device), protocol["evaluation_times_per_song"])
            row.update({f"validation_{k}": metrics[k] for k in ("med", "ccc_v", "ccc_a")})
            if metrics["med"] < best - 1e-7:
                best, best_epoch, best_metrics = metrics["med"], epoch, metrics
                best_weights = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
                stagnant = 0
            else:
                stagnant += 1
        history.append(row)
        if validation_ids and stagnant >= protocol["early_stop_patience"]:
            break
    if validation_ids:
        model.load_state_dict(best_weights)
        return model, best_epoch, best_metrics, history
    return model, iterations, None, history


def _inner_score(store, ids, protocol, candidate, seed, device, variant):
    folds = source_folds(ids, protocol["inner_folds"], seed)
    records = []
    for fold in folds:
        _, _, metrics, _ = fit_model(store, fold["train"], fold["test"], protocol, candidate,
                                      seed + fold["fold"], device, variant)
        records.append(metrics)
    return {"med": float(np.mean([x["med"] for x in records])),
            "ccc_sum": float(np.mean([x["ccc_v"]+x["ccc_a"] for x in records]))}


def select_hyperparameters(store, weight_ids: list[str], protocol: dict, seed: int,
                           device: str, variant: str = "full") -> tuple[dict, list[dict]]:
    """Ordered source-only inner search specified by the manuscript."""
    params = copy.deepcopy(protocol["initial_values_not_realized_selections"])
    trace = []
    groups = [("learning_rate",), ("lambda_r", "lambda_b"), ("beta",),
              ("huber_kappa",), ("reliability_scale",), ("lambda_delta",)]
    from itertools import product
    for keys in groups:
        values = product(*(protocol["candidate_grids"][key] for key in keys))
        candidates = []
        for combination in values:
            proposed = {**params, **dict(zip(keys, combination))}
            score = _inner_score(store, weight_ids, protocol, proposed, seed, device, variant)
            candidates.append((proposed, score))
            trace.append({"stage": "+".join(keys), "parameters": proposed, "score": score})
        best_med = min(x[1]["med"] for x in candidates)
        near = [x for x in candidates if x[1]["med"] <= best_med + 0.002]
        params = max(near, key=lambda x: x[1]["ccc_sum"])[0]
    return params, trace


def median_inner_epoch(store, weight_ids: list[str], protocol: dict, params: dict,
                       seed: int, device: str, variant: str = "full") -> int:
    chosen = []
    for fold in source_folds(weight_ids, protocol["inner_folds"], seed):
        _, epoch, _, _ = fit_model(store, fold["train"], fold["test"], protocol, params,
                                   seed + fold["fold"], device, variant)
        chosen.append(epoch)
    return int(np.median(chosen))


def run_source_cv(store: SongStore, protocol: dict, output_dir: str, device: str,
                  folds_json: str | None = None, variant: str = "full") -> dict:
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    backbone_id, revision = store.resolved_backbone()
    if backbone_id != protocol["backbone"]:
        raise ValueError("Extracted checkpoint name and protocol backbone differ")
    folds = json.loads(Path(folds_json).read_text()) if folds_json else source_folds(
        store.ids(), protocol["outer_folds"], protocol["random_seed_for_new_runs"])
    if len(folds) != protocol["outer_folds"] or sorted(x for f in folds for x in f["test"]) != store.ids():
        raise ValueError("Outer test folds must form a partition of all source songs")
    for f in folds:
        if set(f["train"]) != set(store.ids()) - set(f["test"]):
            raise ValueError("Outer training songs must exactly exclude that fold's test songs")
    all_scores = []
    for fold in folds:
        label = int(fold["fold"]); fold_dir = out/f"fold_{label}"; fold_dir.mkdir(exist_ok=True)
        weight_ids, calibration_ids = reserve_calibration(
            fold["train"], protocol["calibration_fraction"], protocol["random_seed_for_new_runs"]+label)
        params, trace = select_hyperparameters(store, weight_ids, protocol,
                                                protocol["random_seed_for_new_runs"]+label, device, variant)
        epoch = median_inner_epoch(store, weight_ids, protocol, params,
                                   protocol["random_seed_for_new_runs"]+label, device, variant)
        model, _, _, history = fit_model(store, weight_ids, None, protocol, params,
                                         protocol["random_seed_for_new_runs"]+label, device, variant, epoch)
        prediction = predict(model, store, fold["test"], device)
        calibration = predict(model, store, calibration_ids, device)
        widths = {axis: residual_half_width(calibration, 0.1, axis) for axis in ("v", "a")}
        result = evaluate_tracks(prediction, protocol["evaluation_times_per_song"])
        result.update({f"calibrated_{k}": v for k, v in coverage_width(prediction, widths).items()})
        result["fold"] = label; all_scores.append(result)
        prediction.to_csv(fold_dir/"held_out_predictions.csv", index=False)
        calibration.to_csv(fold_dir/"calibration_predictions.csv", index=False)
        pd.DataFrame(history).to_csv(fold_dir/"training_history.csv", index=False)
        (fold_dir/"selection.json").write_text(json.dumps({"selected": params, "epochs": epoch,
             "training_songs": weight_ids, "calibration_songs": calibration_ids,
             "outer_test_songs": fold["test"], "search": trace,
             "result": result, "widths": widths}, indent=2)+"\n")
        import torch
        torch.save(model.state_dict(), fold_dir/"adapter.pt")
    summary = {key: fold_summary(row[key] for row in all_scores)
               for key in ("ccc_v", "ccc_a", "med", "mae_v", "mae_a", "rmse_v", "rmse_a")}
    (out/"summary.json").write_text(json.dumps({"folds": all_scores, "summary": summary,
        "backbone_revision_resolved": revision}, indent=2)+"\n")
    return summary


def run_final_external(source: SongStore, destination: SongStore, protocol: dict,
                       output_dir: str, device: str, variant: str = "full",
                       identity_audit: str | None = None) -> dict:
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    source_backbone = source.resolved_backbone()
    if source_backbone != destination.resolved_backbone() or source_backbone[0] != protocol["backbone"]:
        raise ValueError("Source and destination features must use the same frozen checkpoint")
    if identity_audit is None:
        raise ValueError("Provide a completed cross-corpus acoustic identity audit before external evaluation")
    audit = json.loads(Path(identity_audit).read_text())
    if audit.get("shared_identifiers") or audit.get("identical_file_hashes") or not audit.get("acoustic_excerpt_match_verified"):
        raise ValueError("Identity audit does not establish nonoverlapping source and external recordings")
    if set(audit.get("source_song_ids", [])) != set(source.ids()) or set(audit.get("external_song_ids", [])) != set(destination.ids()):
        raise ValueError("Identity audit song lists do not match the requested source/external collections")
    if any(x.lower().startswith("deam_") for x in destination.ids()):
        raise ValueError("DEAM anchor songs remain in external data")
    weight_ids, cal_ids = reserve_calibration(source.ids(), protocol["calibration_fraction"],
                                             protocol["random_seed_for_new_runs"])
    if len(source.ids()) == 1802 and len(cal_ids) != 181:
        raise AssertionError("Final source reservation must contain 181 songs")
    params, trace = select_hyperparameters(source, weight_ids, protocol,
                                            protocol["random_seed_for_new_runs"], device, variant)
    epochs = median_inner_epoch(source, weight_ids, protocol, params,
                                protocol["random_seed_for_new_runs"], device, variant)
    model, _, _, history = fit_model(source, weight_ids, None, protocol, params,
                                     protocol["random_seed_for_new_runs"], device, variant, epochs)
    cal = predict(model, source, cal_ids, device)
    widths = {axis: residual_half_width(cal, 0.1, axis) for axis in ("v", "a")}
    import torch
    torch.save(model.state_dict(), out/"adapter.pt")
    record = {"selected": params, "epochs": epochs, "training_songs": weight_ids,
              "calibration_songs": cal_ids, "interval_half_widths": widths,
              "backbone": source_backbone[0], "backbone_revision": source_backbone[1],
              "search": trace, "identity_audit": str(Path(identity_audit).resolve())}
    (out/"selection.json").write_text(json.dumps(record, indent=2)+"\n")
    pd.DataFrame(history).to_csv(out/"training_history.csv", index=False)
    cal.to_csv(out/"source_calibration_predictions.csv", index=False)
    external = predict(model, destination, destination.ids(), device)
    external.to_csv(out/"external_predictions.csv", index=False)
    metrics = evaluate_tracks(external, protocol["evaluation_times_per_song"])
    metrics.update(coverage_width(external, widths))
    metrics["song_bootstrap"] = bootstrap_track_metrics(external,
        protocol["external_bootstrap_replicates"], protocol["statistical_seed"],
        protocol["evaluation_times_per_song"])
    (out/"external_metrics.json").write_text(json.dumps(metrics, indent=2)+"\n")
    return metrics


def run_stress_prediction(destination: SongStore, protocol: dict, fitted_dir: str,
                          output_dir: str, device: str) -> dict:
    """Never fit weights or select a threshold on the perturbed destination."""
    import torch
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    selected = json.loads((Path(fitted_dir)/"selection.json").read_text())
    if destination.resolved_backbone() != (selected["backbone"], selected["backbone_revision"]):
        raise ValueError("Perturbed features do not match the frozen fitted backbone")
    model = new_model(protocol, "full", device)
    model.load_state_dict(torch.load(Path(fitted_dir)/"adapter.pt", map_location=device, weights_only=True))
    prediction = predict(model, destination, destination.ids(), device)
    prediction.to_csv(out/"stress_predictions.csv", index=False)
    result = evaluate_tracks(prediction, protocol["evaluation_times_per_song"])
    (out/"stress_metrics.json").write_text(json.dumps(result, indent=2)+"\n")
    return result


def run_reduced_source(source: SongStore, destination: SongStore, protocol: dict,
                       fitted_dir: str, fraction: float, seed: int,
                       output_dir: str, device: str) -> dict:
    """Preserve final source selection and epoch; change intact weight-fitting songs only."""
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    record = json.loads((Path(fitted_dir)/"selection.json").read_text())
    if source.resolved_backbone() != (record["backbone"], record["backbone_revision"]) or \
       destination.resolved_backbone() != source.resolved_backbone():
        raise ValueError("Feature checkpoint mismatch in reduced-source evaluation")
    eligible = record["training_songs"]
    n = math.ceil(fraction*len(eligible))
    if not 0 < n <= len(eligible) or set(eligible) & set(record["calibration_songs"]):
        raise ValueError("Invalid reduced-source partition")
    subset = sorted(np.random.default_rng(seed).choice(eligible, n, replace=False).tolist())
    model, _, _, history = fit_model(source, subset, None, protocol, record["selected"],
                                     seed, device, epochs=record["epochs"])
    external = predict(model, destination, destination.ids(), device)
    external.to_csv(out/"external_predictions.csv", index=False)
    pd.DataFrame(history).to_csv(out/"training_history.csv", index=False)
    result = evaluate_tracks(external, protocol["evaluation_times_per_song"])
    (out/"selection.json").write_text(json.dumps({"subset_song_ids": subset, "seed": seed,
            "fraction": fraction, "parent_selection": str(Path(fitted_dir).resolve()),
            "source_calibration_songs": record["calibration_songs"],
            "external_metrics": result}, indent=2)+"\n")
    return result
