"""Corpus normalization, identity audit, and song-level partitions."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

REQUIRED_COLUMNS = ("song_id", "time", "valence", "arousal")


def _audio_index(root: str | Path) -> dict[str, str]:
    root = Path(root)
    paths = sorted(p for p in root.rglob("*") if p.suffix.lower() in {".mp3", ".wav", ".flac", ".ogg"})
    index: dict[str, str] = {}
    for path in paths:
        key = path.stem.lower()
        if key in index:
            raise ValueError(f"Audio stem is ambiguous: {key}: {path} and {index[key]}")
        index[key] = str(path.resolve())
    if not paths:
        raise FileNotFoundError(f"No decoded audio files under {root}")
    return index


def _read_deam_wide(path: str | Path, axis: str, time_mode: str) -> pd.DataFrame:
    frame = pd.read_csv(path)
    if frame.shape[1] < 61:
        raise ValueError(f"Expected song identifier and at least 60 time columns: {path}")
    song_col = next((x for x in frame if str(x).lower() in {"song_id", "song", "id"}), frame.columns[0])
    columns = [x for x in frame if x != song_col]
    if time_mode == "header_seconds":
        try:
            times = [float(str(x).replace("s", "")) for x in columns]
        except ValueError as exc:
            raise ValueError(f"Time column is not numeric in {path}; choose index_from_15s") from exc
    elif time_mode == "index_from_15s":
        times = [15.0 + 0.5 * j for j in range(len(columns))]
    else:
        raise ValueError("time_mode must be header_seconds or index_from_15s")
    if min(times) < 15.0 or len(set(times)) != len(times):
        raise ValueError(f"DEAM time axis is invalid or still includes the first 15 seconds: {path}")
    tidy = frame.melt(id_vars=[song_col], value_vars=columns, var_name="column", value_name=axis)
    tidy["song_id"] = tidy[song_col].astype(str).str.replace(r"\.0$", "", regex=True)
    tidy["time"] = tidy["column"].map(dict(zip(columns, times)))
    tidy[axis] = pd.to_numeric(tidy[axis], errors="coerce")
    if tidy.duplicated(["song_id", "time"]).any():
        raise ValueError(f"Duplicate DEAM song/time pair in {path}")
    return tidy[["song_id", "time", axis]]


def prepare_deam(valence: str, arousal: str, sd_valence: str, sd_arousal: str,
                 audio_dir: str, output_dir: str, time_mode: str) -> dict:
    """Join the four published dynamic-annotation matrices on ID and physical time."""
    output = Path(output_dir); output.mkdir(parents=True, exist_ok=True)
    tables = [_read_deam_wide(p, name, time_mode) for p, name in (
        (valence, "valence"), (arousal, "arousal"),
        (sd_valence, "sd_valence"), (sd_arousal, "sd_arousal"))]
    combined = tables[0]
    for part in tables[1:]:
        combined = combined.merge(part, on=["song_id", "time"], how="outer", validate="one_to_one")
    audio = _audio_index(audio_dir)
    ids = set(combined.song_id.unique())
    missing = sorted(x for x in ids if x.lower() not in audio)
    if missing:
        raise ValueError(f"DEAM audio absent for {len(missing)} annotated IDs; first IDs: {missing[:8]}")
    valid = combined[["valence", "arousal"]].notna().all(axis=1)
    combined["audio_path"] = combined.song_id.map(lambda x: audio[x.lower()])
    combined["corpus"] = "DEAM"
    combined.sort_values(["song_id", "time"]).to_csv(output / "annotations.csv", index=False)
    return audit_annotations(combined, expected_songs=1802, output=output / "audit.json", valid=valid)


def prepare_merp(parquet: str, audio_dir: str, output_dir: str,
                 excluded_ids: list[str] | None = None) -> dict:
    """Average filtered rater series without redoing the authors' filtering."""
    output = Path(output_dir); output.mkdir(parents=True, exist_ok=True)
    trials = pd.read_parquet(parquet)
    if not {"song_id", "valence", "arousal"}.issubset(trials):
        raise ValueError("Expected song_id, valence and arousal array columns")
    audio = _audio_index(audio_dir)
    excluded = set(excluded_ids or [])
    rows = []
    for song_id, group in trials.groupby("song_id", sort=True):
        song_id = str(song_id)
        if song_id in excluded or song_id.lower().startswith("deam_"):
            continue
        if song_id.lower() not in audio:
            raise FileNotFoundError(f"MERP audio missing: {song_id}")
        n = min(max(len(x) for x in group.valence), max(len(x) for x in group.arousal))
        for axis in ("valence", "arousal"):
            if any(not isinstance(x, (np.ndarray, list, tuple)) for x in group[axis]):
                raise TypeError(f"{axis} should contain sampled rating arrays")
        v = np.full((len(group), n), np.nan, dtype=float)
        a = np.full_like(v, np.nan)
        for j, (_, trial) in enumerate(group.iterrows()):
            v[j, :min(n, len(trial.valence))] = np.asarray(trial.valence[:n], dtype=float)
            a[j, :min(n, len(trial.arousal))] = np.asarray(trial.arousal[:n], dtype=float)
        for j in range(n):
            vv, aa = v[:, j], a[:, j]
            vv, aa = vv[np.isfinite(vv)], aa[np.isfinite(aa)]
            rows.append((song_id, j / 10.0, float(vv.mean()) if len(vv) else math.nan,
                         float(aa.mean()) if len(aa) else math.nan,
                         float(vv.std(ddof=1)) if len(vv) > 1 else math.nan,
                         float(aa.std(ddof=1)) if len(aa) > 1 else math.nan,
                         audio[song_id.lower()], "MERP"))
    frame = pd.DataFrame(rows, columns=["song_id", "time", "valence", "arousal",
                                         "sd_valence", "sd_arousal", "audio_path", "corpus"])
    if frame.empty:
        raise ValueError("No nonanchor MERP songs")
    frame.to_csv(output / "annotations.csv", index=False)
    return audit_annotations(frame, expected_songs=50, output=output / "audit.json")


def audit_annotations(frame: pd.DataFrame, expected_songs: int | None = None,
                      output: str | Path | None = None, valid=None) -> dict:
    if not set(REQUIRED_COLUMNS).issubset(frame):
        raise ValueError(f"Missing one or more columns: {REQUIRED_COLUMNS}")
    frame = frame.copy()
    valid = frame[["valence", "arousal"]].notna().all(axis=1) if valid is None else valid
    n = frame.song_id.nunique()
    if expected_songs is not None and n != expected_songs:
        raise ValueError(f"Expected {expected_songs} unique recordings, obtained {n}; stop and audit release")
    per_song = frame.groupby("song_id").apply(
        lambda f: int(f[["valence", "arousal"]].notna().all(axis=1).sum()), include_groups=False)
    if per_song.min() < 60:
        raise ValueError(f"Fewer than 60 paired valid times for {int((per_song < 60).sum())} songs")
    if frame.duplicated(["song_id", "time"]).any():
        raise ValueError("Duplicate song/time keys")
    if (frame.time < 0).any():
        raise ValueError("Negative timestamps")
    result = {"recordings": int(n), "rows": int(len(frame)), "paired_valid_rows": int(valid.sum()),
              "paired_missing_fraction": float(1 - valid.mean()),
              "valid_time_min": float(frame.loc[valid, "time"].min()),
              "valid_time_max": float(frame.loc[valid, "time"].max()),
              "paired_valid_per_song_min": int(per_song.min()),
              "recordings_below_60": int((per_song < 60).sum())}
    for axis in ("valence", "arousal"):
        vals = frame.loc[valid, axis].to_numpy(dtype=float)
        if np.any(np.abs(vals) > 1.000001):
            raise ValueError(f"{axis} label outside [-1,1]")
        result[axis] = {"mean": float(vals.mean()), "sd": float(vals.std(ddof=1)),
                        "min": float(vals.min()), "max": float(vals.max()),
                        "missing_fraction": float(frame[axis].isna().mean())}
    if output is not None:
        Path(output).write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def source_folds(song_ids: list[str], n_folds: int, seed: int) -> list[dict]:
    ids = np.array(sorted(set(song_ids)), dtype=str)
    if n_folds < 2 or len(ids) < n_folds:
        raise ValueError("Insufficient groups for the requested folds")
    np.random.default_rng(seed).shuffle(ids)
    blocks = np.array_split(ids, n_folds)
    return [{"fold": j + 1, "train": sorted(x for k, b in enumerate(blocks) if k != j for x in b),
             "test": sorted(blocks[j].tolist())} for j in range(n_folds)]


def reserve_calibration(song_ids: list[str], fraction: float, seed: int) -> tuple[list[str], list[str]]:
    ids = np.array(sorted(set(song_ids)), dtype=str)
    np.random.default_rng(seed).shuffle(ids)
    n_cal = math.ceil(len(ids) * fraction)
    if not 0 < n_cal < len(ids):
        raise ValueError("Calibration reservation must leave weight-fitting songs")
    return sorted(ids[n_cal:].tolist()), sorted(ids[:n_cal].tolist())


def selected_times(frame: pd.DataFrame, k: int = 60) -> np.ndarray:
    valid = frame.loc[frame[["valence", "arousal"]].notna().all(axis=1)].sort_values("time")
    n = len(valid)
    if n < k:
        raise ValueError(f"Only {n} paired times, need {k}")
    positions = np.floor((np.arange(k) + 0.5) * n / k).astype(int)
    if len(set(positions.tolist())) != k:
        raise AssertionError("Subsample repeated a timestamp")
    return valid.iloc[positions].time.to_numpy(dtype=float)


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def audit_track_identity(source: pd.DataFrame, external: pd.DataFrame) -> dict:
    """Exact checks; excerpt-to-full-song matching requires separate acoustic review."""
    src = source[["song_id", "audio_path"]].drop_duplicates()
    ext = external[["song_id", "audio_path"]].drop_duplicates()
    src_ids = set(src.song_id.astype(str).str.lower())
    shared_ids = sorted(src_ids & set(ext.song_id.astype(str).str.lower()))
    src_hash = {sha256_file(row.audio_path): str(row.song_id) for row in src.itertuples()}
    common_hash = []
    for row in ext.itertuples():
        digest = sha256_file(row.audio_path)
        if digest in src_hash:
            common_hash.append((str(row.song_id), src_hash[digest]))
    return {"shared_identifiers": shared_ids, "identical_file_hashes": common_hash,
            "acoustic_excerpt_match_verified": False,
            "note": "Exact hashes cannot exclude a 45-second excerpt within a differently encoded full song."
            }
