"""Frozen MERT2 extraction with padded-frame masking and immutable cache keys."""

from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path

import numpy as np
from scipy.signal import resample_poly


def read_audio(path: str, sample_rate: int = 24000) -> np.ndarray:
    import soundfile as sf
    waveform, source_rate = sf.read(path, always_2d=True, dtype="float32")
    mono = waveform.mean(axis=1)
    if source_rate != sample_rate:
        gcd = math.gcd(source_rate, sample_rate)
        mono = resample_poly(mono, sample_rate//gcd, source_rate//gcd).astype("float32")
    if mono.size < sample_rate:
        raise ValueError(f"Audio shorter than one second: {path}")
    if not np.isfinite(mono).all():
        raise ValueError(f"Nonfinite audio in {path}")
    return mono


def window_bounds(duration: float, window: float = 30.0, stride: float = 15.0) -> list[tuple[float,float]]:
    if duration <= 0 or not 0 < stride <= window:
        raise ValueError("Invalid duration/window/stride")
    starts = np.arange(0, duration, stride)
    return [(float(s), min(float(s+window), duration)) for s in starts
            if s == 0 or s < duration - 1e-7]


def cache_key(path: str, model_name: str, revision: str | None, sample_rate: int,
              window: float, stride: float) -> str:
    info = Path(path).stat()
    payload = json.dumps([str(Path(path).resolve()), info.st_size, info.st_mtime_ns,
                          model_name, revision, sample_rate, window, stride])
    return hashlib.sha256(payload.encode()).hexdigest()[:24]


class MERT2Extractor:
    def __init__(self, model_id: str = "m-a-p/MERT-v2-30s", revision: str | None = None,
                 device: str = "cpu"):
        import torch
        from huggingface_hub import model_info
        from transformers import AutoFeatureExtractor, AutoModel
        resolved_revision = revision or model_info(model_id).sha
        self.torch, self.device, self.model_id, self.revision = torch, device, model_id, resolved_revision
        self.processor = AutoFeatureExtractor.from_pretrained(
            model_id, revision=resolved_revision, trust_remote_code=True)
        self.model = AutoModel.from_pretrained(
            model_id, revision=resolved_revision, trust_remote_code=True).eval().to(device)
        for parameter in self.model.parameters():
            parameter.requires_grad_(False)
        if self.processor.sampling_rate != 24000:
            raise ValueError("The manuscript's MERT2 checkpoint requires 24 kHz input")

    def encode(self, audio: np.ndarray, start: float, end: float,
               sample_rate: int = 24000, window_seconds: float = 30.0) -> dict:
        a, b = round(start*sample_rate), round(end*sample_rate)
        segment = audio[a:b]
        full_length = round(window_seconds*sample_rate)
        if len(segment) > full_length:
            raise ValueError("Input longer than one foundation-model window")
        padded = np.pad(segment, (0, full_length-len(segment)))
        inputs = self.processor(padded, sampling_rate=sample_rate, return_tensors="pt")
        inputs = {name: value.to(self.device) for name, value in inputs.items()}
        with self.torch.inference_mode():
            result = self.model(**inputs, output_hidden_states=True)
        post = result.hidden_states
        if len(post) != 24:
            raise ValueError(f"Expected exactly 24 MERT2 post-block tensors, found {len(post)}")
        hidden = self.torch.stack([layer[0] for layer in post]).cpu().to(self.torch.float16).numpy()
        n = hidden.shape[1]
        relative_time = np.arange(n, dtype=np.float64)/25.0
        keep = relative_time <= (end-start)+1e-6
        if np.count_nonzero(keep) < 2:
            raise ValueError("Insufficient valid MERT2 frames")
        return {"hidden": hidden[:, keep], "frame_times": relative_time[keep] + start,
                "start": start, "end": end}


def extract_track(audio_path: str, target_dir: str | Path, extractor: MERT2Extractor,
                  window_seconds: float = 30.0, stride_seconds: float = 15.0,
                  noise_seed: int | None = None, snr_db: float | None = None) -> dict:
    target = Path(target_dir); target.mkdir(parents=True, exist_ok=True)
    wave = read_audio(audio_path)
    if (noise_seed is None) != (snr_db is None):
        raise ValueError("Noise seed and SNR must be supplied together")
    if snr_db is not None:
        track_seed = int(hashlib.sha256((str(noise_seed)+"/"+str(Path(audio_path).resolve())).encode()).hexdigest()[:16], 16)
        rng = np.random.default_rng(track_seed)
        noise = rng.normal(size=len(wave)).astype("float32")
        noise -= noise.mean()
        signal_power = float(np.mean(np.square(wave, dtype=np.float64)))
        noise_power = float(np.mean(np.square(noise, dtype=np.float64)))
        if signal_power <= 0 or noise_power <= 0:
            raise ValueError("Whole-track signal/noise power must be positive")
        wave = wave + noise * math.sqrt(signal_power / (10**(snr_db/10)*noise_power))
    bounds = window_bounds(len(wave)/24000, window_seconds, stride_seconds)
    windows = []
    for w, (start, end) in enumerate(bounds):
        frame = extractor.encode(wave, start, end, window_seconds=window_seconds)
        name = f"window_{w:04d}.npz"
        np.savez_compressed(target / name, **frame)
        windows.append(name)
    manifest = {"source_path": str(Path(audio_path).resolve()), "model": extractor.model_id,
                "revision": extractor.revision, "song_duration": len(wave)/24000,
                "windows": windows, "sample_rate": 24000,
                "window_seconds": window_seconds, "stride_seconds": stride_seconds,
                "noise_seed": noise_seed, "snr_db": snr_db,
                "audio_cache_key": cache_key(audio_path, extractor.model_id, extractor.revision,
                                             24000, window_seconds, stride_seconds)}
    (target / "manifest.json").write_text(json.dumps(manifest, indent=2)+"\n")
    return manifest


def load_windows(path: str | Path) -> list[dict]:
    import torch
    root = Path(path)
    info = json.loads((root/"manifest.json").read_text())
    if Path(info["source_path"]).exists() and info.get("audio_cache_key") != cache_key(
            info["source_path"], info["model"], info["revision"], info["sample_rate"],
            info["window_seconds"], info["stride_seconds"]):
        raise ValueError("The audio file changed after frozen-feature extraction")
    windows = []
    for name in info["windows"]:
        with np.load(root/name) as item:
            windows.append({"hidden": torch.as_tensor(item["hidden"].astype("float32")),
                            "frame_times": torch.as_tensor(item["frame_times"].astype("float32")),
                            "start": float(item["start"]), "end": float(item["end"])})
    return windows


def load_song(annotation_rows, feature_root: str | Path) -> dict:
    rows = annotation_rows.sort_values("time")
    rows = rows[rows[["valence", "arousal"]].notna().all(axis=1)]
    if len(rows) < 60:
        raise ValueError("The evaluation protocol needs 60 paired times per song")
    sid = str(rows.song_id.iloc[0])
    sd = rows[["sd_valence", "sd_arousal"]].to_numpy(dtype="float32")
    return {"song_id": sid, "time": rows.time.to_numpy(dtype="float32"),
            "target": rows[["valence", "arousal"]].to_numpy(dtype="float32"),
            "sd": sd, "windows": load_windows(Path(feature_root)/sid)}
