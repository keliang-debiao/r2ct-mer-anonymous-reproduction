"""Research implementation for R²CT-MER."""

__version__ = "0.1.0"
