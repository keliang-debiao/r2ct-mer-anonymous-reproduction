"""Track-aware endpoints, calibration, and paired statistical inference."""

from __future__ import annotations

import itertools
import math
from typing import Iterable

import numpy as np
import pandas as pd
from scipy.stats import t as student_t

from .data import selected_times


def ccc(y: np.ndarray, pred: np.ndarray) -> float:
    y, pred = np.asarray(y, float), np.asarray(pred, float)
    if len(y) != len(pred) or len(y) < 2:
        raise ValueError("CCC requires at least two paired values")
    mask = np.isfinite(y) & np.isfinite(pred)
    y, pred = y[mask], pred[mask]
    if len(y) < 2:
        return math.nan
    ym, pm = y.mean(), pred.mean()
    a, b = y - ym, pred - pm
    denominator = np.mean(a * a) + np.mean(b * b) + (ym - pm) ** 2
    return float(2 * np.mean(a * b) / denominator) if denominator > 0 else math.nan


def evaluate_tracks(predictions: pd.DataFrame, k: int = 60) -> dict:
    """Pooled balanced CCC; all valid native times for song-averaged errors."""
    needed = {"song_id", "time", "valence", "arousal", "pred_v", "pred_a"}
    if not needed.issubset(predictions):
        raise ValueError(f"Missing columns: {sorted(needed - set(predictions))}")
    full = predictions.dropna(subset=["valence", "arousal"]).copy()
    if not np.isfinite(full[["pred_v", "pred_a"]].to_numpy(float)).all():
        raise ValueError("A model prediction is absent or nonfinite at an eligible target time")
    if full.duplicated(["song_id", "time"]).any():
        raise ValueError("Prediction keys are not unique")
    selected, song_metrics = [], []
    for sid, song in full.groupby("song_id", sort=True):
        song = song.sort_values("time")
        lookup = selected_times(song, k)
        chosen = song.set_index("time").loc[lookup].reset_index()
        selected.append(chosen)
        yy = song[["valence", "arousal"]].to_numpy(float)
        pp = song[["pred_v", "pred_a"]].to_numpy(float)
        diff = pp - yy
        song_metrics.append({"song_id": str(sid), "med": float(np.linalg.norm(diff, axis=1).mean()),
                             "mae_v": float(np.abs(diff[:, 0]).mean()),
                             "mae_a": float(np.abs(diff[:, 1]).mean()),
                             "rmse_v": float(np.sqrt(np.square(diff[:, 0]).mean())),
                             "rmse_a": float(np.sqrt(np.square(diff[:, 1]).mean()))})
    if not selected:
        raise ValueError("No valid songs")
    point = pd.concat(selected, ignore_index=True)
    macro = pd.DataFrame(song_metrics)
    result = {"songs": int(len(macro)), "pooled_pairs": int(len(point)),
              "ccc_v": ccc(point.valence, point.pred_v),
              "ccc_a": ccc(point.arousal, point.pred_a)}
    for key in ("med", "mae_v", "mae_a", "rmse_v", "rmse_a"):
        result[key] = float(macro[key].mean())
    return result


def paired_song_table(first: pd.DataFrame, second: pd.DataFrame) -> pd.DataFrame:
    """Both prediction sets use exactly the same labels, times, and songs."""
    keys = ["song_id", "time"]
    merged = first.merge(second, on=keys, suffixes=("_first", "_second"), validate="one_to_one")
    if len(merged) != len(first) or len(merged) != len(second):
        raise ValueError("Comparator predictions do not share the same evaluated timestamps")
    for axis in ("valence", "arousal"):
        if not np.allclose(merged[f"{axis}_first"], merged[f"{axis}_second"], equal_nan=True):
            raise ValueError("Reference labels differ between paired models")
    data = []
    for sid, song in merged.groupby("song_id", sort=True):
        y = song[["valence_first", "arousal_first"]].to_numpy(float)
        f = song[["pred_v_first", "pred_a_first"]].to_numpy(float)
        s = song[["pred_v_second", "pred_a_second"]].to_numpy(float)
        data.append((str(sid), float(np.linalg.norm(s-y, axis=1).mean() -
                                      np.linalg.norm(f-y, axis=1).mean())))
    return pd.DataFrame(data, columns=["song_id", "med_reduction_first_vs_second"])


def residual_half_width(calibration: pd.DataFrame, alpha: float, axis: str) -> float:
    if axis not in {"v", "a"} or not 0 < alpha < 1:
        raise ValueError("axis must be v/a and alpha in (0,1)")
    truth = "valence" if axis == "v" else "arousal"
    values = (calibration[truth] - calibration[f"pred_{axis}"]).abs().dropna().to_numpy(float)
    n = len(values)
    if n == 0:
        raise ValueError("No calibration residuals")
    rank = math.ceil((n + 1) * (1 - alpha))
    return float(np.partition(values, rank - 1)[rank - 1]) if rank <= n else math.inf


def coverage_width(target: pd.DataFrame, widths: dict[str, float]) -> dict:
    result = {}
    for axis, key in (("v", "valence"), ("a", "arousal")):
        y = target[key].to_numpy(float)
        pred = target[f"pred_{axis}"].to_numpy(float)
        mask = np.isfinite(y) & np.isfinite(pred)
        lo, hi = np.maximum(-1, pred[mask] - widths[axis]), np.minimum(1, pred[mask] + widths[axis])
        result[f"coverage_{axis}"] = float(((y[mask] >= lo) & (y[mask] <= hi)).mean())
        result[f"width_{axis}"] = float((hi - lo).mean())
    return result


def fold_summary(values: Iterable[float]) -> dict:
    a = np.asarray(list(values), dtype=float)
    n = len(a)
    if n < 2:
        raise ValueError("At least two folds required")
    mean, sd = float(a.mean()), float(a.std(ddof=1))
    delta = student_t.ppf(0.975, n - 1) * sd / math.sqrt(n)
    return {"values": a.tolist(), "mean": mean, "sd": sd,
            "descriptive_95ci": [mean - delta, mean + delta]}


def bootstrap_track_metrics(predictions: pd.DataFrame, replicates: int = 10000,
                            seed: int = 2026, k: int = 60) -> dict:
    """Resample complete songs for pooled CCC and song-macro point errors."""
    tracks = []
    for _, song in predictions.dropna(subset=["valence", "arousal"]).groupby("song_id", sort=True):
        if not np.isfinite(song[["pred_v", "pred_a"]].to_numpy(float)).all():
            raise ValueError("Nonfinite prediction in external track")
        song = song.sort_values("time")
        picked = song.set_index("time").loc[selected_times(song, k)]
        truth = song[["valence", "arousal"]].to_numpy(float)
        predicted = song[["pred_v", "pred_a"]].to_numpy(float)
        error = predicted-truth
        song_errors = [np.linalg.norm(error, axis=1).mean(), *np.abs(error).mean(0),
                       *np.sqrt(np.square(error).mean(0))]
        tracks.append((picked[["valence", "arousal"]].to_numpy(float),
                       picked[["pred_v", "pred_a"]].to_numpy(float), song_errors))
    if len(tracks) < 2:
        raise ValueError("Need at least two independent external songs")
    targets = np.stack([entry[0] for entry in tracks])
    estimates = np.stack([entry[1] for entry in tracks])
    errors = np.stack([entry[2] for entry in tracks])
    n = len(tracks)
    result = np.empty((replicates, 7), dtype=float)
    rng = np.random.default_rng(seed)
    for b in range(replicates):
        take = rng.integers(0, n, size=n)
        yy = targets[take].reshape(n*k, 2)
        pp = estimates[take].reshape(n*k, 2)
        result[b] = [ccc(yy[:, 0], pp[:, 0]), ccc(yy[:, 1], pp[:, 1]),
                     *errors[take].mean(0)]
    return {"resampling_unit": "song", "replicates": replicates, "seed": seed,
            "95ci": {name: np.quantile(result[:, j], [0.025, 0.975]).tolist()
                     for j, name in enumerate(("ccc_v", "ccc_a", "med", "mae_v",
                                               "mae_a", "rmse_v", "rmse_a"))}}


def exact_sign_flip(differences: Iterable[float]) -> dict:
    x = np.asarray(list(differences), float)
    if not len(x) or len(x) > 20:
        raise ValueError("Exact enumeration restricted to 1..20 paired units")
    observed = abs(x.mean())
    all_means = np.array([abs(np.mean(np.asarray(signs) * x))
                          for signs in itertools.product((-1, 1), repeat=len(x))])
    p = float(np.mean(all_means >= observed - 1e-12))
    sd = float(x.std(ddof=1)) if len(x) > 1 else math.nan
    return {"mean_difference": float(x.mean()), "dz": float(x.mean() / sd) if sd else math.nan,
            "two_sided_exact_p": p, "descriptive_95ci": fold_summary(x)["descriptive_95ci"]}


def paired_external_inference(differences: Iterable[float], bootstrap: int = 10000,
                              flips: int = 100000, seed: int = 2026) -> dict:
    x = np.asarray(list(differences), float)
    if len(x) < 2:
        raise ValueError("Need multiple independent songs")
    rng = np.random.default_rng(seed)
    n = len(x)
    samples = np.empty(bootstrap)
    for start in range(0, bootstrap, 512):
        end = min(bootstrap, start + 512)
        samples[start:end] = x[rng.integers(0, n, size=(end - start, n))].mean(axis=1)
    extreme = 0
    for start in range(0, flips, 512):
        rows = min(512, flips - start)
        extreme += int(np.count_nonzero(np.abs((rng.choice([-1, 1], size=(rows, n))*x).mean(axis=1))
                                           >= abs(x.mean()) - 1e-12))
    return {"paired_songs": n, "mean_reduction": float(x.mean()),
            "song_bootstrap_95ci": np.quantile(samples, [0.025, 0.975]).tolist(),
            "dz": float(x.mean() / x.std(ddof=1)),
            "randomization_p_two_sided": float((extreme + 1) / (flips + 1)), "seed": seed}


def holm_adjust(raw_p: Iterable[float]) -> list[float]:
    p = np.asarray(list(raw_p), float)
    order = np.argsort(p)
    adjusted = np.empty_like(p)
    running = 0.0
    for rank, index in enumerate(order):
        running = max(running, min(1.0, float((len(p) - rank) * p[index])))
        adjusted[index] = running
    return adjusted.tolist()
