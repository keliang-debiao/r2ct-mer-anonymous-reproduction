"""R²CT-MER adapter; source labels appear only in the loss function."""

from __future__ import annotations

import math
from dataclasses import dataclass

import torch
from torch import Tensor, nn
from torch.nn import functional as F


def linear_sample(sequence: Tensor, times: Tensor, query: Tensor) -> Tensor:
    """Differentiable linear interpolation at physical time coordinates."""
    if times.ndim != 1 or times.numel() < 2 or sequence.shape[0] != times.numel():
        raise ValueError("A sequence requires at least two ordered valid frames")
    x = query.clamp(min=times[0], max=times[-1])
    right = torch.searchsorted(times.contiguous(), x.contiguous()).clamp(1, len(times)-1)
    left = right - 1
    factor = ((x - times[left]) / (times[right] - times[left]).clamp_min(1e-8))
    while factor.ndim < sequence[left].ndim:
        factor = factor.unsqueeze(-1)
    return sequence[left] * (1-factor) + sequence[right] * factor


@dataclass
class WindowOutput:
    query: Tensor
    prediction: Tensor
    anchor: Tensor
    reliability: Tensor
    delays: Tensor
    start: float
    end: float


class R2CTMER(nn.Module):
    """Frozen-encoder features [24, T, 1024] to queried two-axis ratings."""

    def __init__(self, width: int = 256, score_width: int = 128,
                 offsets: tuple[float, ...] = (-4, -2, -1, 0, 1, 2, 4),
                 max_delay: float = 2.0, variant: str = "full") -> None:
        super().__init__()
        self.width, self.offsets, self.max_delay, self.variant = width, offsets, max_delay, variant
        self.projections = nn.ModuleList(nn.Linear(1024, width) for _ in range(4))
        self.reliability_norm = nn.LayerNorm(width)
        self.reliability_head = nn.Linear(width, 1)
        self.group_score = nn.ModuleList(nn.Linear(width, 1) for _ in range(4))
        self.reliability_interaction = nn.Parameter(torch.zeros(4))
        self.delay_head = nn.Linear(width, 1)
        self.local_features = nn.Linear(width, score_width, bias=False)
        self.offset_features = nn.Linear(3, score_width, bias=False)
        self.score_bias = nn.Parameter(torch.zeros(score_width))
        self.score_vector = nn.Parameter(torch.empty(score_width))
        nn.init.normal_(self.score_vector, std=0.02)
        self.anchor_head = nn.Linear(width, 2)
        self.displacement_head = nn.Linear(width, 2)
        if variant not in {"full", "no_gate", "zero_delay", "constant_delay", "no_anchor",
                           "single_layer", "fixed_probe", "tcn_probe"}:
            raise ValueError(f"Unknown forward ablation: {variant}")
        if variant == "tcn_probe":
            self.tcn = nn.Sequential(nn.Conv1d(width, width, 3, padding=2, dilation=2, groups=width),
                                     nn.GELU(), nn.Conv1d(width, width, 3, padding=4, dilation=4, groups=width))
        if variant in {"fixed_probe", "tcn_probe"}:
            self.probe_head = nn.Sequential(nn.Linear(width, width), nn.GELU(), nn.Linear(width, 2))

    def _fused(self, hidden: Tensor) -> tuple[Tensor, Tensor]:
        if hidden.ndim != 3 or hidden.shape[0] != 24 or hidden.shape[2] != 1024:
            raise ValueError("Expect 24 post-block sequences [24, frames, 1024]")
        projected = torch.stack([layer(hidden[g*6:(g+1)*6].mean(dim=0))
                                 for g, layer in enumerate(self.projections)], dim=1)
        if self.variant == "single_layer":
            projected = self.projections[3](hidden[23]).unsqueeze(1).expand(-1, 4, -1)
        reliability = torch.sigmoid(self.reliability_head(self.reliability_norm(projected.mean(dim=1)))).squeeze(-1)
        scores = torch.cat([head(projected[:, g]) for g, head in enumerate(self.group_score)], dim=-1)
        if self.variant in {"fixed_probe", "tcn_probe"}:
            scores = self.reliability_interaction[None, :].expand(len(scores), -1)
        elif self.variant == "no_gate":
            reliability = torch.full_like(reliability, 0.5)
            scores = scores.detach() * 0 + 0  # exact, nonlearned equal-layer average
        else:
            scores = scores + reliability[:, None] * self.reliability_interaction[None, :]
        return (projected * torch.softmax(scores, dim=-1).unsqueeze(-1)).sum(dim=1), reliability

    def forward_window(self, hidden: Tensor, frame_times: Tensor, requested_times: Tensor,
                       start: float, end: float) -> WindowOutput:
        if requested_times.numel() == 0:
            raise ValueError("No query times for this window")
        fused, reliability_grid = self._fused(hidden)
        query = requested_times.to(hidden.device, dtype=hidden.dtype)
        if self.variant in {"fixed_probe", "tcn_probe"}:
            if self.variant == "tcn_probe":
                fused = fused + self.tcn(fused.T.unsqueeze(0)).squeeze(0).T
            context = linear_sample(fused, frame_times, query)
            return WindowOutput(query, torch.tanh(self.probe_head(context)),
                                self.anchor_head(context.mean(0)),
                                torch.full_like(query, 0.5), torch.zeros_like(query), start, end)
        if self.variant == "zero_delay":
            delay_grid = torch.zeros_like(reliability_grid)
        elif self.variant == "constant_delay":
            delay_grid = self.max_delay * torch.sigmoid(self.delay_head(fused.mean(0))).expand_as(reliability_grid).squeeze(-1)
        else:
            delay_grid = self.max_delay * torch.sigmoid(self.delay_head(fused)).squeeze(-1)

        offsets = torch.as_tensor(self.offsets, device=hidden.device, dtype=hidden.dtype)
        coordinates = query[:, None] + offsets[None, :]
        valid = (coordinates >= start) & (coordinates <= end)
        if not valid[:, self.offsets.index(0.0)].all():
            raise ValueError("Requested time is outside the valid frame interval")
        local_delay = linear_sample(delay_grid[:, None], frame_times, coordinates.flatten()).reshape_as(coordinates)
        lagged = (coordinates - local_delay).clamp(min=max(start, float(frame_times[0])),
                                                   max=min(end, float(frame_times[-1])))
        lagged_audio = linear_sample(fused, frame_times, lagged.flatten()).reshape(len(query), len(offsets), self.width)
        psi = torch.stack((offsets / 4, torch.sin(math.pi*offsets/4), torch.cos(math.pi*offsets/4)), dim=-1)
        score = torch.tanh(self.local_features(lagged_audio) + self.offset_features(psi)[None] +
                           self.score_bias).matmul(self.score_vector)
        score = score.masked_fill(~valid, torch.finfo(score.dtype).min)
        context = (torch.softmax(score, dim=-1).unsqueeze(-1) * lagged_audio).sum(dim=1)
        anchor = self.anchor_head(context.mean(dim=0))
        raw_displacement = self.displacement_head(context)
        if self.variant == "no_anchor":
            prediction = torch.tanh(raw_displacement)
        else:
            prediction = torch.tanh(anchor + raw_displacement - raw_displacement.mean(dim=0))
        return WindowOutput(query, prediction, anchor,
                            linear_sample(reliability_grid[:, None], frame_times, query).squeeze(-1),
                            linear_sample(delay_grid[:, None], frame_times, query).squeeze(-1), start, end)

    def forward_song(self, windows: list[dict], requested_times: Tensor) -> tuple[Tensor, list[WindowOutput]]:
        out = []
        device = next(self.parameters()).device
        query = requested_times.to(device)
        numerator = torch.zeros((len(query), 2), device=device)
        denominator = torch.zeros(len(query), device=device)
        fallback = torch.zeros_like(numerator)
        fallback_set = torch.zeros(len(query), dtype=torch.bool, device=device)
        for window in windows:
            frame_times = window["frame_times"].to(device)
            start, end = float(window["start"]), float(window["end"])
            included = (query >= start) & (query <= end)
            if not included.any():
                continue
            result = self.forward_window(window["hidden"].to(device, dtype=torch.float32),
                                         frame_times, query[included], start, end)
            out.append(result)
            weight = torch.minimum(query[included]-start, end-query[included]).clamp_min(0)
            numerator[included] = numerator[included] + weight[:, None] * result.prediction
            denominator[included] = denominator[included] + weight
            first = included & ~fallback_set
            if first.any():
                # Index through the song's original requested-time positions.
                local_positions = torch.nonzero(included, as_tuple=True)[0]
                for position, val in zip(local_positions, result.prediction):
                    if not fallback_set[position]:
                        fallback[position], fallback_set[position] = val, True
        if not fallback_set.all():
            raise ValueError("At least one query time is uncovered by valid encoder features")
        prediction = torch.where(denominator[:, None] > 0, numerator / denominator[:, None].clamp_min(1e-8), fallback)
        return prediction, out


def concordance_torch(reference: Tensor, predicted: Tensor) -> Tensor | None:
    if reference.numel() < 2 or reference.var(unbiased=False) <= 1e-8:
        return None
    a, b = reference - reference.mean(), predicted - predicted.mean()
    denominator = a.square().mean() + b.square().mean() + (reference.mean()-predicted.mean()).square()
    return 2 * (a*b).mean() / denominator.clamp_min(1e-8)


def training_objective(model: R2CTMER, songs: list[dict], parameters: dict) -> tuple[Tensor, dict]:
    """Song-macro Huber and batch CCC; aux objectives never enter inference."""
    device = next(model.parameters()).device
    hubers, predictions, references, reliability_losses, anchor_losses, delay_losses = [], [], [], [], [], []
    scale = parameters["reliability_scale"]
    for song in songs:
        query = torch.as_tensor(song["time"], device=device, dtype=torch.float32)
        target = torch.as_tensor(song["target"], device=device, dtype=torch.float32)
        pred, windows = model.forward_song(song["windows"], query)
        hubers.append(F.huber_loss(pred, target, reduction="mean", delta=parameters["huber_kappa"]))
        predictions.append(pred)
        references.append(target)
        for output in windows:
            indexes = torch.searchsorted(query, output.query)
            local_target = target[indexes]
            if model.variant not in {"no_anchor", "fixed_probe", "tcn_probe"}:
                anchor_losses.append((torch.tanh(output.anchor)-local_target.mean(0)).abs().mean())
            if len(output.query) > 1:
                delay_losses.append((output.delays[1:]-output.delays[:-1]).abs() /
                                     (output.query[1:]-output.query[:-1]).clamp_min(1e-6))
            if "sd" in song:
                sd = torch.as_tensor(song["sd"], device=device, dtype=torch.float32)[indexes]
                available = torch.isfinite(sd).all(dim=-1)
                if available.any():
                    wanted = torch.exp(-sd[available].square().sum(-1)/(2*scale*scale))
                    reliability_losses.append((output.reliability[available]-wanted).square())
    all_pred, all_target = torch.cat(predictions), torch.cat(references)
    ccc_terms = [1-value for k in range(2)
                 if (value := concordance_torch(all_target[:, k], all_pred[:, k])) is not None]
    zero = all_pred.sum()*0
    robust = torch.stack(hubers).mean()
    main = robust + parameters["beta"]*(torch.stack(ccc_terms).sum() if ccc_terms else zero)
    rel = torch.cat(reliability_losses).mean() if reliability_losses else zero
    anch = torch.stack(anchor_losses).mean() if anchor_losses else zero
    delay = torch.cat(delay_losses).mean() if delay_losses else zero
    total = main + parameters["lambda_r"]*rel + parameters["lambda_b"]*anch + parameters["lambda_delta"]*delay
    return total, {"main": float(main.detach()), "rel": float(rel.detach()),
                   "anchor": float(anch.detach()), "delay": float(delay.detach())}
