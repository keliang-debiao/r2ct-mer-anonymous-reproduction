"""Command line entry points for corpus preparation and locked evaluation."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def protocol_at(path: str) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="r2ct-mer")
    commands = p.add_subparsers(dest="command", required=True)
    deam = commands.add_parser("prepare-deam")
    for field in ("valence", "arousal", "sd-valence", "sd-arousal", "audio-dir", "output"):
        deam.add_argument("--" + field, required=True)
    deam.add_argument("--time-mode", choices=["header_seconds", "index_from_15s"], required=True)
    merp = commands.add_parser("prepare-merp")
    for field in ("parquet", "audio-dir", "output"):
        merp.add_argument("--" + field, required=True)
    merp.add_argument("--exclude-id", action="append", default=[])
    audit = commands.add_parser("identity-audit")
    for field in ("source", "external", "output"):
        audit.add_argument("--" + field, required=True)
    extract = commands.add_parser("extract")
    for field in ("annotations", "output"):
        extract.add_argument("--" + field, required=True)
    extract.add_argument("--protocol", default="configs/protocol.json")
    extract.add_argument("--device", default="cpu")
    noise = commands.add_parser("noise-extract")
    for field in ("annotations", "output"):
        noise.add_argument("--" + field, required=True)
    noise.add_argument("--protocol", default="configs/protocol.json")
    noise.add_argument("--device", default="cpu")
    noise.add_argument("--seed", type=int, required=True)
    noise.add_argument("--snr-db", type=float, choices=[10.0, 20.0], required=True)
    for task in ("source-cv", "external", "ablation"):
        sub = commands.add_parser(task)
        for field in ("source", "source-features", "output"):
            sub.add_argument("--" + field, required=True)
        sub.add_argument("--protocol", default="configs/protocol.json")
        sub.add_argument("--device", default="cpu")
        if task == "source-cv":
            sub.add_argument("--folds-json")
            sub.add_argument("--variant", default="full")
        else:
            for field in ("external", "external-features", "identity-audit"):
                sub.add_argument("--" + field, required=True)
            if task == "external":
                sub.add_argument("--variant", default="full")
            else:
                sub.add_argument("--variants", nargs="+", default=["full", "no_gate", "no_reliability_loss",
                    "zero_delay", "constant_delay", "no_anchor", "no_anchor_loss", "single_layer"])
    pair = commands.add_parser("paired-inference")
    pair.add_argument("--first", required=True)
    pair.add_argument("--second", required=True)
    pair.add_argument("--output", required=True)
    pair.add_argument("--protocol", default="configs/protocol.json")
    stress = commands.add_parser("stress-evaluate")
    for field in ("external", "external-features", "fitted-dir", "output"):
        stress.add_argument("--" + field, required=True)
    stress.add_argument("--protocol", default="configs/protocol.json")
    stress.add_argument("--device", default="cpu")
    reduced = commands.add_parser("reduced-source")
    for field in ("source", "source-features", "external", "external-features", "fitted-dir", "output"):
        reduced.add_argument("--" + field, required=True)
    reduced.add_argument("--fraction", type=float, choices=[0.5, 0.75], required=True)
    reduced.add_argument("--seed", type=int, required=True)
    reduced.add_argument("--protocol", default="configs/protocol.json")
    reduced.add_argument("--device", default="cpu")
    desc = commands.add_parser("descriptor-extract")
    desc.add_argument("--annotations", required=True)
    desc.add_argument("--output", required=True)
    for task in ("descriptor-cv", "descriptor-external"):
        sub = commands.add_parser(task)
        sub.add_argument("--source", required=True)
        sub.add_argument("--model", choices=["ridge", "random_forest", "xgboost", "mlp"], required=True)
        sub.add_argument("--output", required=True)
        sub.add_argument("--protocol", default="configs/protocol.json")
        if task == "descriptor-cv":
            sub.add_argument("--folds-json")
        else:
            sub.add_argument("--external", required=True)
            sub.add_argument("--identity-audit", required=True)
    dry = commands.add_parser("synthetic-dry-run")
    dry.add_argument("--output", required=True)
    env = commands.add_parser("environment")
    env.add_argument("--output", required=True)
    return p


def main(argv: list[str] | None = None) -> None:
    args = parser().parse_args(argv)
    if args.command == "prepare-deam":
        from .data import prepare_deam
        result = prepare_deam(args.valence, args.arousal, args.sd_valence,
                              args.sd_arousal, args.audio_dir, args.output, args.time_mode)
    elif args.command == "prepare-merp":
        from .data import prepare_merp
        result = prepare_merp(args.parquet, args.audio_dir, args.output, args.exclude_id)
    elif args.command == "identity-audit":
        from .data import audit_track_identity
        source = pd.read_csv(args.source, dtype={"song_id": str})
        external = pd.read_csv(args.external, dtype={"song_id": str})
        result = audit_track_identity(source, external)
        result["source_song_ids"] = sorted(source.song_id.unique().tolist())
        result["external_song_ids"] = sorted(external.song_id.unique().tolist())
        result["acoustic_excerpt_match_verified"] = False
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output).write_text(json.dumps(result, indent=2)+"\n", encoding="utf-8")
    elif args.command in {"extract", "noise-extract"}:
        from .features import MERT2Extractor, extract_track
        p = protocol_at(args.protocol)
        extractor = MERT2Extractor(p["backbone"], p["backbone_revision"], args.device)
        annotations = pd.read_csv(args.annotations, dtype={"song_id": str})
        source = annotations[["song_id", "audio_path"]].drop_duplicates()
        if source.duplicated("song_id").any():
            raise ValueError("One song ID maps to multiple audio paths")
        result = {}
        for row in source.itertuples():
            result[row.song_id] = extract_track(row.audio_path, Path(args.output)/row.song_id,
                                                 extractor, p["window_seconds"], p["stride_seconds"],
                                                 args.seed if args.command == "noise-extract" else None,
                                                 args.snr_db if args.command == "noise-extract" else None)
        (Path(args.output)/"extraction.json").write_text(json.dumps(result, indent=2)+"\n")
        result = {"tracks_extracted": len(result), "feature_directory": args.output}
    elif args.command in {"source-cv", "external", "ablation"}:
        from .train import SongStore, run_source_cv, run_final_external
        p = protocol_at(args.protocol)
        source = SongStore(args.source, args.source_features)
        if args.command == "source-cv":
            result = run_source_cv(source, p, args.output, args.device, args.folds_json, args.variant)
        else:
            external = SongStore(args.external, args.external_features)
            if args.command == "external":
                result = run_final_external(source, external, p, args.output, args.device,
                                            args.variant, args.identity_audit)
            else:
                result = {}
                for variant in args.variants:
                    variant_dir = Path(args.output)/variant
                    source_scores = run_source_cv(source, p, str(variant_dir/"source_cv"),
                                                  args.device, variant=variant)
                    external_scores = run_final_external(source, external, p,
                        str(variant_dir/"external"), args.device, variant, args.identity_audit)
                    result[variant] = {"source": source_scores, "external": external_scores}
                Path(args.output).mkdir(parents=True, exist_ok=True)
                (Path(args.output)/"ablation_metrics.json").write_text(json.dumps(result, indent=2)+"\n")
    elif args.command == "paired-inference":
        from .evaluate import paired_song_table, paired_external_inference
        p = protocol_at(args.protocol)
        first, second = (pd.read_csv(x, dtype={"song_id": str}) for x in (args.first, args.second))
        paired = paired_song_table(first, second)
        result = paired_external_inference(paired.med_reduction_first_vs_second,
            p["external_bootstrap_replicates"], p["external_sign_flip_replicates"], p["statistical_seed"])
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output).write_text(json.dumps(result, indent=2)+"\n")
    elif args.command == "stress-evaluate":
        from .train import SongStore, run_stress_prediction
        result = run_stress_prediction(SongStore(args.external, args.external_features),
            protocol_at(args.protocol), args.fitted_dir, args.output, args.device)
    elif args.command == "reduced-source":
        from .train import SongStore, run_reduced_source
        result = run_reduced_source(SongStore(args.source, args.source_features),
            SongStore(args.external, args.external_features), protocol_at(args.protocol),
            args.fitted_dir, args.fraction, args.seed, args.output, args.device)
    elif args.command == "descriptor-extract":
        from .descriptors import extract_descriptors
        records = extract_descriptors(args.annotations, args.output)
        result = {"rows": len(records), "songs": int(records.song_id.nunique()), "output": args.output}
    elif args.command in {"descriptor-cv", "descriptor-external"}:
        from .baselines import descriptor_cv, descriptor_external
        p = protocol_at(args.protocol)
        if args.command == "descriptor-cv":
            result = descriptor_cv(args.source, args.model, args.output,
                                   p["random_seed_for_new_runs"], args.folds_json)
        else:
            result = descriptor_external(args.source, args.external, args.model,
                                         args.identity_audit, args.output,
                                         p["random_seed_for_new_runs"])
    elif args.command == "environment":
        import importlib.metadata as metadata
        import platform
        import sys
        names = ["numpy", "pandas", "scipy", "scikit-learn", "torch", "torchaudio",
                 "transformers", "huggingface-hub", "librosa", "soundfile", "xgboost"]
        versions = {}
        for name in names:
            try:
                versions[name] = metadata.version(name)
            except metadata.PackageNotFoundError:
                versions[name] = None
        result = {"python": sys.version, "platform": platform.platform(), "packages": versions}
        Path(args.output).parent.mkdir(parents=True, exist_ok=True)
        Path(args.output).write_text(json.dumps(result, indent=2)+"\n")
    else:
        from .dry_run import run
        result = run(args.output)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
