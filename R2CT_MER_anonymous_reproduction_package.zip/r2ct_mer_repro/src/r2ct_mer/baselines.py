"""Fold-locked descriptor controls; each fitted transform stays within source songs."""

from __future__ import annotations

import json
from itertools import product
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.impute import SimpleImputer
from sklearn.linear_model import Ridge
from sklearn.multioutput import MultiOutputRegressor
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

from .data import reserve_calibration, source_folds
from .descriptors import FEATURE_NAMES
from .evaluate import evaluate_tracks, fold_summary


class TorchMLPRegressor:
    """Two hidden-layer descriptor regression with actual train-time dropout."""

    def __init__(self, width: int, dropout: float, seed: int, epochs: int = 50):
        self.width, self.dropout, self.seed, self.epochs = width, dropout, seed, epochs

    def fit(self, x, y):
        import torch
        from torch import nn
        from torch.utils.data import DataLoader, TensorDataset
        torch.manual_seed(self.seed)
        x = torch.as_tensor(np.asarray(x), dtype=torch.float32)
        y = torch.as_tensor(np.asarray(y), dtype=torch.float32)
        self.net = nn.Sequential(nn.Linear(x.shape[1], self.width), nn.ReLU(), nn.Dropout(self.dropout),
                                 nn.Linear(self.width, self.width), nn.ReLU(), nn.Dropout(self.dropout),
                                 nn.Linear(self.width, 2))
        optimizer = torch.optim.AdamW(self.net.parameters(), lr=3e-4, weight_decay=0.01)
        loader = DataLoader(TensorDataset(x, y), batch_size=512, shuffle=True)
        for _ in range(self.epochs):
            self.net.train()
            for xx, yy in loader:
                optimizer.zero_grad(set_to_none=True)
                loss = nn.functional.smooth_l1_loss(self.net(xx), yy)
                loss.backward()
                optimizer.step()
        self.net.eval()
        return self

    def predict(self, x):
        import torch
        with torch.no_grad():
            return self.net(torch.as_tensor(np.asarray(x), dtype=torch.float32)).numpy()


def candidates(model_name: str):
    if model_name == "ridge":
        for alpha in (0.1, 1.0, 10.0):
            yield {"alpha": alpha}
    elif model_name == "random_forest":
        for trees, depth in product((200, 500), (8, None)):
            yield {"n_estimators": trees, "max_depth": depth}
    elif model_name == "xgboost":
        for depth, rate in product((3, 6), (0.03, 0.1)):
            yield {"max_depth": depth, "learning_rate": rate, "n_estimators": 300}
    elif model_name == "mlp":
        for width, dropout in product((128, 256), (0.1, 0.3)):
            yield {"width": width, "dropout": dropout}
    else:
        raise ValueError("Unknown descriptor control")


def estimator(model_name: str, params: dict, seed: int):
    if model_name == "ridge":
        return make_pipeline(SimpleImputer(strategy="median"), StandardScaler(), Ridge(**params))
    if model_name == "random_forest":
        return make_pipeline(SimpleImputer(strategy="median"),
                             RandomForestRegressor(**params, random_state=seed, n_jobs=1))
    if model_name == "xgboost":
        from xgboost import XGBRegressor
        return make_pipeline(SimpleImputer(strategy="median"),
            MultiOutputRegressor(XGBRegressor(**params, random_state=seed, n_jobs=1)))
    return make_pipeline(SimpleImputer(strategy="median"), StandardScaler(),
                         TorchMLPRegressor(**params, seed=seed))


def fit_predict(source: pd.DataFrame, train_ids: list[str], validation: pd.DataFrame,
                model_name: str, parameters: dict, seed: int):
    training = source[source.song_id.isin(train_ids)].dropna(subset=["valence", "arousal"])
    if len(training) == 0:
        raise ValueError("Training set has no paired ratings")
    model = estimator(model_name, parameters, seed)
    model.fit(training[FEATURE_NAMES], training[["valence", "arousal"]])
    output = validation.copy()
    output[["pred_v", "pred_a"]] = np.clip(model.predict(validation[FEATURE_NAMES]), -1, 1)
    return model, output


def select(source: pd.DataFrame, train_ids: list[str], model_name: str, seed: int,
           inner_folds: int = 3):
    splits = source_folds(train_ids, inner_folds, seed)
    results = []
    for parameters in candidates(model_name):
        scores = []
        for fold in splits:
            validation = source[source.song_id.isin(fold["test"])].dropna(subset=["valence", "arousal"])
            _, prediction = fit_predict(source, fold["train"], validation, model_name, parameters, seed)
            scores.append(evaluate_tracks(prediction)["med"])
        results.append({"parameters": parameters, "inner_med": float(np.mean(scores))})
    best = min(results, key=lambda row: row["inner_med"])
    return best["parameters"], results


def descriptor_cv(source_csv: str, model_name: str, output: str, seed: int = 2026,
                  folds_json: str | None = None):
    source = pd.read_csv(source_csv, dtype={"song_id": str})
    ids = sorted(source.song_id.unique())
    folds = json.loads(Path(folds_json).read_text()) if folds_json else source_folds(ids, 5, seed)
    if len(folds) != 5 or sorted(s for f in folds for s in f["test"]) != ids:
        raise ValueError("Invalid five-fold partition")
    out = Path(output); out.mkdir(parents=True, exist_ok=True)
    metrics = []
    for fold in folds:
        weights, _ = reserve_calibration(fold["train"], 0.1, seed+fold["fold"])
        params, trace = select(source, weights, model_name, seed+fold["fold"])
        held = source[source.song_id.isin(fold["test"])].dropna(subset=["valence", "arousal"])
        _, prediction = fit_predict(source, weights, held, model_name, params, seed+fold["fold"])
        row = evaluate_tracks(prediction); row["fold"] = fold["fold"]
        metrics.append(row)
        prediction.to_csv(out/f"fold_{fold['fold']}_predictions.csv", index=False)
        (out/f"fold_{fold['fold']}_selection.json").write_text(json.dumps(
            {"parameters": params, "search": trace, "weight_songs": weights,
             "test_songs": fold["test"]}, indent=2)+"\n")
    result = {"folds": metrics, "summary": {key: fold_summary(row[key] for row in metrics)
              for key in ("ccc_v", "ccc_a", "med", "mae_v", "mae_a", "rmse_v", "rmse_a")}}
    (out/"summary.json").write_text(json.dumps(result, indent=2)+"\n")
    return result["summary"]


def descriptor_external(source_csv: str, external_csv: str, model_name: str,
                        identity_audit: str, output: str, seed: int = 2026):
    source = pd.read_csv(source_csv, dtype={"song_id": str})
    external = pd.read_csv(external_csv, dtype={"song_id": str})
    audit = json.loads(Path(identity_audit).read_text())
    if audit.get("shared_identifiers") or audit.get("identical_file_hashes") or not audit.get("acoustic_excerpt_match_verified"):
        raise ValueError("Cross-corpus identity audit is incomplete")
    if sorted(audit.get("source_song_ids", [])) != sorted(source.song_id.unique()) or \
       sorted(audit.get("external_song_ids", [])) != sorted(external.song_id.unique()):
        raise ValueError("Identity audit track lists do not match descriptor files")
    weights, calibration = reserve_calibration(sorted(source.song_id.unique()), 0.1, seed)
    params, trace = select(source, weights, model_name, seed)
    external = external.dropna(subset=["valence", "arousal"])
    _, pred = fit_predict(source, weights, external, model_name, params, seed)
    out = Path(output); out.mkdir(parents=True, exist_ok=True)
    pred.to_csv(out/"external_predictions.csv", index=False)
    result = evaluate_tracks(pred)
    (out/"selection.json").write_text(json.dumps({"parameters": params, "search": trace,
        "weight_songs": weights, "calibration_songs": calibration, "identity_audit": identity_audit}, indent=2)+"\n")
    (out/"external_metrics.json").write_text(json.dumps(result, indent=2)+"\n")
    return result
