"""Deterministic synthetic check of splitting, metrics, and paired inference only."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pandas as pd

from .data import reserve_calibration, source_folds
from .evaluate import evaluate_tracks, exact_sign_flip, fold_summary, paired_song_table


NOTICE = "SYNTHETIC DRY RUN — NOT EMPIRICAL DEAM/MERP RESULT"


def run(output: str) -> dict:
    rng = np.random.default_rng(20261014)
    songs = [f"generated_{i:02d}" for i in range(15)]
    folds = source_folds(songs, 5, 2026)
    data = []
    for i, sid in enumerate(songs):
        offset = 0.30*np.sin(i)
        for index in range(80):
            t = 15+index*0.5
            val = np.clip(offset+0.25*np.sin(t/7+i/3), -1, 1)
            aro = np.clip(0.10+0.32*np.cos(t/8+i/4), -1, 1)
            data.append((sid, t, val, aro, np.clip(val+rng.normal(0, 0.18), -1, 1),
                         np.clip(aro+rng.normal(0, 0.15), -1, 1)))
    predictions = pd.DataFrame(data, columns=["song_id", "time", "valence", "arousal", "pred_v", "pred_a"])
    rows = []
    for fold in folds:
        weights, calibration = reserve_calibration(fold["train"], 0.1, 2026+fold["fold"])
        assert set(weights).isdisjoint(calibration)
        assert set(weights).isdisjoint(fold["test"])
        assert set(calibration).isdisjoint(fold["test"])
        score = evaluate_tracks(predictions[predictions.song_id.isin(fold["test"])], 60)
        rows.append({"fold": fold["fold"], "songs": len(fold["test"]),
                     "ccc_v": score["ccc_v"], "ccc_a": score["ccc_a"], "med": score["med"]})
    summary = {key: fold_summary(row[key] for row in rows) for key in ("ccc_v", "ccc_a", "med")}
    poorer = predictions.copy()
    poorer["pred_v"] += 0.04
    poorer["pred_a"] -= 0.05
    difference = paired_song_table(predictions, poorer)
    paired = exact_sign_flip(difference.med_reduction_first_vs_second)
    payload = {"record_type": NOTICE, "scope": "NumPy metric and partition smoke test only",
               "seed": 20261014, "folds": rows, "summary": summary, "paired": paired}
    location = Path(output)
    location.parent.mkdir(parents=True, exist_ok=True)
    location.write_text(NOTICE+"\n"+json.dumps(payload, indent=2)+"\n", encoding="utf-8")
    return {"record_type": NOTICE, "log": str(location), "fold_count": len(rows)}
