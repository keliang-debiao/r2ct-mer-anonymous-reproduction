"""Time-aligned 45 acoustic descriptors and 45 physical-time differences."""

from __future__ import annotations

import numpy as np
import pandas as pd

from .features import read_audio


FEATURE_NAMES = [f"d{j:02d}" for j in range(90)]


def descriptor_grid(audio_path: str, sample_rate: int = 24000,
                    fft: int = 2048, hop: int = 480) -> tuple[np.ndarray, np.ndarray]:
    import librosa
    signal = read_audio(audio_path, sample_rate)
    spectrum = np.abs(librosa.stft(signal, n_fft=fft, hop_length=hop, center=True))
    power = spectrum**2
    mel = librosa.feature.melspectrogram(S=power, sr=sample_rate, n_mels=128)
    cepstrum = librosa.feature.mfcc(S=librosa.power_to_db(mel), n_mfcc=20)
    chroma = librosa.feature.chroma_stft(S=spectrum, sr=sample_rate, n_fft=fft)
    contrast = librosa.feature.spectral_contrast(S=spectrum, sr=sample_rate, n_fft=fft)
    if contrast.shape[0] != 7:
        raise ValueError("Seven spectral-contrast bands were expected")
    terms = [cepstrum, chroma, contrast,
             librosa.feature.rms(S=spectrum),
             librosa.feature.spectral_centroid(S=spectrum, sr=sample_rate),
             librosa.feature.spectral_bandwidth(S=spectrum, sr=sample_rate),
             librosa.feature.spectral_rolloff(S=spectrum, sr=sample_rate),
             librosa.feature.spectral_flatness(S=spectrum),
             librosa.feature.zero_crossing_rate(signal, frame_length=fft, hop_length=hop)]
    n = min(x.shape[1] for x in terms)
    grid = np.concatenate([x[:, :n] for x in terms], axis=0).T
    if grid.shape[1] != 45:
        raise AssertionError("The descriptor grid has an unexpected width")
    return librosa.frames_to_time(np.arange(n), sr=sample_rate, hop_length=hop), grid


def interpolate_grid(times: np.ndarray, frames: np.ndarray, query: np.ndarray) -> np.ndarray:
    return np.column_stack([np.interp(query, times, frames[:, j])
                            for j in range(frames.shape[1])])


def extract_descriptors(annotations: str, output: str) -> pd.DataFrame:
    frame = pd.read_csv(annotations, dtype={"song_id": str})
    features = []
    for sid, song in frame.groupby("song_id", sort=True):
        paths = song.audio_path.unique()
        if len(paths) != 1:
            raise ValueError(f"Ambiguous audio for {sid}")
        times, grid = descriptor_grid(paths[0])
        query = song.time.to_numpy(float)
        center = interpolate_grid(times, grid, query)
        left = interpolate_grid(times, grid, query-0.25)
        right = interpolate_grid(times, grid, query+0.25)
        backward = (center-left)/0.25
        forward = (right-center)/0.25
        central = (right-left)/0.5
        differences = np.where((query < times[0]+0.25)[:, None], forward, central)
        differences = np.where((query > times[-1]-0.25)[:, None], backward, differences)
        out = song[["song_id", "time", "valence", "arousal"]].copy()
        out[FEATURE_NAMES] = np.concatenate([center, differences], axis=1)
        features.append(out)
    result = pd.concat(features, ignore_index=True)
    from pathlib import Path
    Path(output).parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output, index=False)
    return result
