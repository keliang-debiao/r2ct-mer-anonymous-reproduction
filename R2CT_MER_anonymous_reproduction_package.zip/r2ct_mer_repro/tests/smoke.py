"""Dependency-light executable checks for the data and inference statistics."""

import math
import unittest

import numpy as np
import pandas as pd

from r2ct_mer.data import reserve_calibration, source_folds
from r2ct_mer.evaluate import bootstrap_track_metrics, evaluate_tracks, exact_sign_flip, fold_summary


class CoreProtocolChecks(unittest.TestCase):
    def test_song_partition(self):
        ids = [str(i) for i in range(1802)]
        folds = source_folds(ids, 5, 2026)
        self.assertEqual([len(f["test"]) for f in folds], [361, 361, 360, 360, 360])
        self.assertEqual(sorted(s for f in folds for s in f["test"]), sorted(ids))
        fitting, cal = reserve_calibration(ids, 0.1, 2026)
        self.assertEqual((len(fitting), len(cal)), (1621, 181))
        self.assertFalse(set(fitting) & set(cal))

    def test_metric_and_resampling(self):
        rows = []
        for i in range(5):
            for j in range(80):
                val = (i-2)*0.1+0.03*math.sin(j/6)
                aro = 0.05*math.cos(j/5)+i*0.03
                rows.append((str(i), 15+j*0.5, val, aro, val+0.02, aro-0.03))
        frame = pd.DataFrame(rows, columns=["song_id", "time", "valence", "arousal", "pred_v", "pred_a"])
        result = evaluate_tracks(frame)
        self.assertEqual(result["pooled_pairs"], 300)
        self.assertAlmostEqual(result["med"], math.sqrt(0.02**2+0.03**2))
        interval = bootstrap_track_metrics(frame, 100, 2026)
        self.assertIn("med", interval["95ci"])
        self.assertEqual(len(interval["95ci"]["med"]), 2)

    def test_exact_small_sample(self):
        self.assertAlmostEqual(exact_sign_flip([0.1, 0.2, 0.3, 0.4])["two_sided_exact_p"], 0.125)
        self.assertAlmostEqual(fold_summary([1, 2, 3, 4, 5])["sd"], math.sqrt(2.5))


if __name__ == "__main__":
    unittest.main()
