import math

import numpy as np
import pandas as pd
import pytest

from r2ct_mer.data import reserve_calibration, selected_times, source_folds
from r2ct_mer.evaluate import ccc, evaluate_tracks, exact_sign_flip, fold_summary, holm_adjust
from r2ct_mer.features import window_bounds


def test_disjoint_partition_and_calibration():
    ids = [f"track_{j}" for j in range(25)]
    folds = source_folds(ids, 5, 77)
    assert sorted(s for f in folds for s in f["test"]) == sorted(ids)
    for fold in folds:
        weights, cal = reserve_calibration(fold["train"], 0.1, 78)
        assert len(weights) + len(cal) == 20
        assert len(cal) == 2
        assert set(weights).isdisjoint(cal)
        assert set(weights + cal).isdisjoint(fold["test"])


def test_native_time_selection_and_song_aggregation():
    rows = []
    for sid, baseline in [("one", -0.4), ("two", 0.4)]:
        for j in range(80):
            truth = baseline + 0.1 * math.sin(j / 10)
            rows.append((sid, j / 10, truth, truth / 2, truth + 0.1, truth / 2 - 0.1))
    frame = pd.DataFrame(rows, columns=["song_id", "time", "valence", "arousal", "pred_v", "pred_a"])
    assert len(selected_times(frame[frame.song_id == "one"], 60)) == 60
    result = evaluate_tracks(frame, 60)
    assert result["pooled_pairs"] == 120
    assert result["med"] == pytest.approx(math.sqrt(0.02))
    assert result["mae_v"] == pytest.approx(0.1)


def test_ccc_and_statistics():
    assert ccc(np.array([-0.5, 0.5]), np.array([-0.5, 0.5])) == pytest.approx(1.0)
    assert exact_sign_flip([0.1, 0.2, 0.3, 0.4])["two_sided_exact_p"] == pytest.approx(0.125)
    assert holm_adjust([0.01, 0.04, 0.03]) == pytest.approx([0.03, 0.06, 0.06])
    assert fold_summary([1, 2, 3, 4, 5])["sd"] == pytest.approx(math.sqrt(2.5))


def test_valid_windows():
    assert window_bounds(45) == [(0.0, 30.0), (15.0, 45.0), (30.0, 45.0)]


def test_forward_gradients_if_torch_installed():
    torch = pytest.importorskip("torch")
    from r2ct_mer.model import R2CTMER, training_objective
    model = R2CTMER(width=16, score_width=8)
    song = {"song_id": "generated", "time": np.arange(15, 19, 0.5, dtype="float32"),
            "target": np.zeros((8, 2), dtype="float32"), "sd": np.full((8, 2), 0.1, dtype="float32"),
            "windows": [{"hidden": torch.randn(24, 751, 1024),
                         "frame_times": torch.arange(751) / 25,
                         "start": 0.0, "end": 30.0}]}
    params = {"reliability_scale": 0.25, "huber_kappa": 0.1, "beta": 0.2,
              "lambda_r": 0.1, "lambda_b": 0.1, "lambda_delta": 0.01}
    loss, parts = training_objective(model, [song], params)
    assert torch.isfinite(loss)
    loss.backward()
    assert model.projections[0].weight.grad is not None
    assert set(parts) == {"main", "rel", "anchor", "delay"}
