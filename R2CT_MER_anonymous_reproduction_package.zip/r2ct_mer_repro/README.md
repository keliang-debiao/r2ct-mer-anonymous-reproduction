# R²CT-MER: anonymous source-to-external reproduction package

This repository implements the audio-only Reliability-Guided Relative-Displacement Continuous-Time Music Emotion Regressor. It provides source-only model selection, song-disjoint five-fold evaluation, a separately fitted frozen external evaluation, module deletions, basic descriptor controls, interval estimation, noise and reduced-source stress routines, and paired song-level inference. It contains **no DEAM or MERP audio, human annotations, pretrained weights, or measured manuscript scores**. The checked-in `logs/synthetic_dry_run.log` begins with **SYNTHETIC DRY RUN — NOT EMPIRICAL DEAM/MERP RESULT** and only checks NumPy splitting, metrics, and statistical routines. It must never be cited as experimental evidence.

## Source and permitted use

| Resource | Public record | Role |
|---|---|---|
| DEAM | https://cvml.unige.ch/databases/DEAM/ ; https://www.kaggle.com/datasets/imsparsh/deam-mediaeval-dataset-emotional-analysis-in-music | 1,802 recording development corpus; averaged dynamic mean and standard deviation in both dimensions |
| MERP | https://github.com/dorienh/MERP ; https://www.kaggle.com/datasets/kohenyan/music-emotion-recognition-with-profile-information | 54 original songs; exclude four DEAM anchors to evaluate 50 tracks |
| MERT-v2-30s | https://huggingface.co/m-a-p/MERT-v2-30s | frozen 24-layer 24 kHz encoder; the download commit is resolved and saved with each extraction |

Check each audio track's license and the DEAM and MERT-v2 noncommercial terms before use. The datasets are downloaded outside this repository. Availability of the cleaned MERP trial Parquet and the four DEAM dispersion tables in a particular Kaggle mirror has to be checked against that mirror's current file list; if absent, use the linked public source release and record its file checksums. This code requires the filtered, per-rater MERP trajectory arrays, not a replacement song-level emotion table. Do not reconstruct excluded raters or insert nonexistent annotations.

## Installation and runtime record

Python 3.10 or newer, a compatible PyTorch installation, and disk space for a large frozen 632M-parameter encoder and extracted layer features are required. The package does not bundle model weights or infer compute costs from parameter count. Within an isolated environment:

```bash
python -m pip install -e '.[comparison,test]'
r2ct-mer environment --output artifacts/environment.json
python tests/smoke.py
python -m pytest -q tests
r2ct-mer synthetic-dry-run --output artifacts/synthetic_dry_run.log
```

For a full new run, archive `artifacts/environment.json`, the resolved Hugging Face commit in every feature manifest, the source release file hashes, all selected hyperparameters, fold song IDs, and command outputs. `configs/protocol.json` records the paper's candidate grid. Its `initial_values_not_realized_selections` and seed `random_seed_for_new_runs` are explicitly new-run settings; the prior experiment's realized fold assignment, checkpoint revision, and selections cannot be reconstructed from printed aggregate results. Supply these records to establish byte-for-byte replication of a past run. Otherwise the procedure is a protocol reproduction and its numerical values can differ.

## Corpus normalization

The source command expects four released *wide* matrices keyed by recording ID, each with chronologically ordered dynamic columns. Specify the time convention after inspecting the actual CSV headers. `index_from_15s` assigns 15.0, 15.5, and later seconds to columns in order; `header_seconds` reads numeric seconds from the headers. Do not crop 15 seconds a second time. Filenames here are shell variables set to the verified, unmodified release paths.

```bash
r2ct-mer prepare-deam \
  --valence "$DEAM_VALENCE" --arousal "$DEAM_AROUSAL" \
  --sd-valence "$DEAM_SD_VALENCE" --sd-arousal "$DEAM_SD_AROUSAL" \
  --audio-dir "$DEAM_AUDIO" --output data/deam \
  --time-mode index_from_15s
r2ct-mer prepare-merp \
  --parquet "$MERP_FILTERED_PARQUET" --audio-dir "$MERP_AUDIO" \
  --output data/merp
```

The DEAM join is one-to-one by song ID and time. The MERP conversion averages the already filtered rater arrays at native 10 Hz and derives across-rater standard deviations; MERP standard deviations are never fed to external inference. Corpus audit stops on missing files, ambiguous audio stems, duplicate keys, out-of-range labels, mismatched song counts, or fewer than 60 paired valid timestamps. Review `data/deam/audit.json` and `data/merp/audit.json` rather than assuming release-level counts imply eligible track counts.

## Identity screening and feature extraction

```bash
r2ct-mer identity-audit --source data/deam/annotations.csv \
  --external data/merp/annotations.csv --output artifacts/identity_audit.json
r2ct-mer extract --annotations data/deam/annotations.csv \
  --output data/deam_features --device cuda
r2ct-mer extract --annotations data/merp/annotations.csv \
  --output data/merp_features --device cuda
```

The generated identity audit checks matching song IDs and exact file SHA-256, but it intentionally sets `acoustic_excerpt_match_verified` to `false`: a differently encoded short excerpt can occur within another full song. A researcher must screen cross-corpus acoustic matches, record the method and decisions, and set this field to `true` only after no shared recordings remain. Both full-model and descriptor external commands stop until this documented check is complete. Excluded DEAM anchor IDs must be absent. This human completion is a provenance statement, not an inferred computation.

MERT-v2 processes overlapping 30-second windows at a 15-second stride. Four consecutive six-layer group means are retained from 24 post-block sequences, with padded feature frames masked. Features are stored as half-precision arrays but projected in single precision. The resolved checkpoint commit and audio path are written to each track manifest. Check both corpora use the same commit before model fitting. Cached features are for clean-audio runs; noise experiments re-encode perturbed waveforms.

## Five-fold selection and external evaluation

```bash
r2ct-mer source-cv --source data/deam/annotations.csv \
  --source-features data/deam_features --output artifacts/source_cv --device cuda
r2ct-mer external --source data/deam/annotations.csv \
  --source-features data/deam_features \
  --external data/merp/annotations.csv --external-features data/merp_features \
  --identity-audit artifacts/identity_audit.json \
  --output artifacts/final --device cuda
```

To use saved song partitions, supply `--folds-json` to `source-cv`; it must list five objects with `fold`, `train`, and `test` song-ID lists, disjoint within each object and partitioning all source IDs across the five test lists. Source outer folds contain 1,802 recordings in total. In each outer training partition, upward-rounded 10% of songs are set aside for interval calibration; only the remaining songs enter inner tuning and weight fitting. The final source fit reserves 181 songs for intervals and uses the remaining 1,621 for inner search and weights. At no point are MERP ratings used for tuning, preprocessing fits, or threshold selection.

The ordered source-only candidate search in `train.py` follows learning rate; reliability and anchor weights jointly; CCC weight; Huber transition; reliability scale; delay smoothness weight. Three inner song folds select candidates by mean MED and use summed CCC within 0.002 MED of the minimum. The median selected stopping epoch is used for the outer/final weight fit. `source_cv/fold_*/selection.json` and `final/selection.json` preserve selected values and exact song IDs. `adapter.pt` contains trainable adapter weights, not the frozen encoder. The full inference path uses audio and requested native timestamps only; dispersion and source rating means enter training objectives alone.

The evaluation routine concatenates exactly 60 valid native time pairs per song for pooled CCC, while song-macro MAE, RMSE, and mean Euclidean distance use all paired native times. It refuses nonfinite model predictions at an eligible target time. Source 95% fold intervals are descriptive Student-$t$ summaries, not independent-corpus guarantees. Source residual intervals are fitted on reserved songs, clipped to the target range, and assessed on source held-out tracks and the destination without an external coverage guarantee.

## Component, comparator, and stress runs

```bash
r2ct-mer ablation --source data/deam/annotations.csv \
  --source-features data/deam_features \
  --external data/merp/annotations.csv --external-features data/merp_features \
  --identity-audit artifacts/identity_audit.json \
  --output artifacts/ablation --device cuda
r2ct-mer descriptor-extract --annotations data/deam/annotations.csv \
  --output data/deam_descriptors.csv
r2ct-mer descriptor-extract --annotations data/merp/annotations.csv \
  --output data/merp_descriptors.csv
r2ct-mer descriptor-cv --source data/deam_descriptors.csv \
  --model ridge --output artifacts/ridge_cv
r2ct-mer descriptor-external --source data/deam_descriptors.csv \
  --external data/merp_descriptors.csv --model ridge \
  --identity-audit artifacts/identity_audit.json --output artifacts/ridge_external
r2ct-mer external --source data/deam/annotations.csv \
  --source-features data/deam_features \
  --external data/merp/annotations.csv --external-features data/merp_features \
  --identity-audit artifacts/identity_audit.json \
  --variant fixed_probe --output artifacts/fixed_probe --device cuda
r2ct-mer paired-inference \
  --first artifacts/final/external_predictions.csv \
  --second artifacts/fixed_probe/external_predictions.csv \
  --output artifacts/paired_fixed_probe.json
```

`--variant fixed_probe` and `--variant tcn_probe` run same-backbone controls through the source and final commands. Descriptor commands also support `random_forest`, `xgboost`, and `mlp`; they use 20 MFCC, 12 chroma, seven contrast, six spectral features, and physical-time first differences. Each imputer and scaler is fitted only inside the corresponding source weight partition. These runnable controls do **not** implement every architecture reported in the paper's broad comparator table. TabNet, FT-Transformer, Conformer, DAMFF, DSAML, MERT-v1, and PupuM2D-Large require their separately verified implementation and encoder weights. Their manuscript scores cannot be regenerated by this repository as it stands. Do not describe this archive alone as a complete reproduction of those comparator rows.

For the reported white-noise conditions, reuse the same clean annotation file and generate a separate extracted feature directory for every SNR and seed. The seed deterministically varies by track; the 20 dB and 10 dB conditions for the same track and seed share the underlying Gaussian realization. No clipping follows noise addition.

```bash
r2ct-mer noise-extract --annotations data/merp/annotations.csv \
  --output data/merp_noise_20db_2027 --seed 2027 --snr-db 20 --device cuda
r2ct-mer stress-evaluate --external data/merp/annotations.csv \
  --external-features data/merp_noise_20db_2027 --fitted-dir artifacts/final \
  --output artifacts/noise_20db_2027 --device cuda
r2ct-mer reduced-source --source data/deam/annotations.csv \
  --source-features data/deam_features \
  --external data/merp/annotations.csv --external-features data/merp_features \
  --fitted-dir artifacts/final --fraction 0.75 --seed 2027 \
  --output artifacts/subset_75_2027 --device cuda
```

Repeat both SNRs and both fractions with seeds 2027–2031. `reduced-source` keeps the final source-only configuration and chosen epoch, sampling upward-rounded 1,216 or 811 intact weight-fitting songs. Calibration songs remain excluded. Summarize five independent seed runs as mean ± sample SD and descriptive $t_4$ intervals. Model deletion rows require separate source training, not masking components on a previously trained checkpoint. Interval coverage under transfer and song-level paired inference may be computed from saved predictions; source-fold sign flips can be computed with `exact_sign_flip` and Holm correction with `holm_adjust` in `evaluate.py`.

## Audit boundaries

The package was assembled from the stated manuscript protocol and publicly documented model interfaces. The checked-in dry-run log validates only lightweight computation. Full DEAM/MERP extraction, GPU model optimization, matching all manuscript scores, independent acoustic screening, and all published comparator implementations need the actual public corpora and a complete compute run. A reviewer should assess the resulting *real* prediction files and source-provenance record, not the checked-in synthetic log. No result should be reported as verified from this archive until its data-specific commands have finished and their outputs have been audited.
